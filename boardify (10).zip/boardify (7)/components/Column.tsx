"use client"

import { useState } from "react"
import { Draggable, Droppable } from "react-beautiful-dnd"
import Task from "./Task"
import { Plus, Edit2, Trash2 } from "lucide-react"

interface Task {
  id: string
  title: string
  description: string
  priority: "low" | "medium" | "high"
  assignee: string
}

interface ColumnProps {
  column: {
    id: string
    title: string
    tasks: Task[]
    color: string
  }
  openTaskModal: (columnId: string, task: Task | null) => void
  deleteTask: (columnId: string, taskId: string) => void
  updateColumn: (columnId: string, newTitle: string, newColor: string) => void
  deleteColumn: (columnId: string) => void
  dragHandleProps: any
}

export default function Column({
  column,
  openTaskModal,
  deleteTask,
  updateColumn,
  deleteColumn,
  dragHandleProps,
}: ColumnProps) {
  const [isEditing, setIsEditing] = useState(false)
  const [newTitle, setNewTitle] = useState(column.title)
  const [newColor, setNewColor] = useState(column.color)

  const handleUpdateColumn = () => {
    updateColumn(column.id, newTitle, newColor)
    setIsEditing(false)
  }

  return (
    <div
      className="bg-white dark:bg-gray-800 rounded-lg shadow-lg flex flex-col h-full rounded-xl"
      style={{ borderTop: `8px solid ${column.color}` }}
    >
      <div className="px-4 py-3 flex justify-between items-center" {...dragHandleProps}>
        {isEditing ? (
          <div className="flex items-center space-x-2">
            <input
              type="text"
              value={newTitle}
              onChange={(e) => setNewTitle(e.target.value)}
              className="border rounded px-2 py-1 text-sm"
            />
            <input type="color" value={newColor} onChange={(e) => setNewColor(e.target.value)} className="w-6 h-6" />
            <button onClick={handleUpdateColumn} className="text-green-500 hover:text-green-600">
              <Edit2 size={16} />
            </button>
          </div>
        ) : (
          <h2 className="text-lg font-semibold">{column.title}</h2>
        )}
        <div className="flex items-center space-x-2">
          {!isEditing && (
            <button onClick={() => setIsEditing(true)} className="text-gray-500 hover:text-gray-700">
              <Edit2 size={16} />
            </button>
          )}
          <button
            onClick={() => deleteColumn(column.id)}
            className="text-gray-500 hover:text-red-500 transition-colors duration-200"
          >
            <Trash2 size={16} />
          </button>
        </div>
      </div>
      <Droppable droppableId={column.id} type="task">
        {(provided, snapshot) => (
          <div
            ref={provided.innerRef}
            {...provided.droppableProps}
            className={`p-2 flex-grow ${snapshot.isDraggingOver ? "bg-gray-100 dark:bg-gray-700" : ""}`}
          >
            {column.tasks.map((task, index) => (
              <Draggable key={task.id} draggableId={task.id} index={index}>
                {(provided, snapshot) => (
                  <Task
                    task={task}
                    provided={provided}
                    snapshot={snapshot}
                    openTaskModal={() => openTaskModal(column.id, task)}
                    onDelete={() => deleteTask(column.id, task.id)}
                  />
                )}
              </Draggable>
            ))}
            {provided.placeholder}
          </div>
        )}
      </Droppable>
      <div className="p-2">
        <button
          onClick={() => openTaskModal(column.id, null)}
          className="w-full flex items-center justify-center px-4 py-2 bg-gray-100 dark:bg-gray-700 text-gray-700 dark:text-gray-300 rounded-md hover:bg-gray-200 dark:hover:bg-gray-600 transition-colors duration-200"
        >
          <Plus size={20} className="mr-2" />
          Add Task
        </button>
      </div>
    </div>
  )
}

