import { Trash2 } from "lucide-react"
import type React from "react"

interface TaskProps {
  task: {
    id: string
    title: string
    description: string
    priority: "low" | "medium" | "high"
    assignee: string
  }
  provided: any
  snapshot: any
  openTaskModal: () => void
  onDelete: () => void
}

export default function Task({ task, provided, snapshot, openTaskModal, onDelete }: TaskProps) {
  const priorityColors = {
    low: "bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-100",
    medium: "bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-100",
    high: "bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-100",
  }

  const handleDelete = (e: React.MouseEvent) => {
    e.stopPropagation()
    if (confirm("Are you sure you want to delete this task?")) {
      onDelete()
    }
  }

  return (
    <div
      ref={provided.innerRef}
      {...provided.draggableProps}
      {...provided.dragHandleProps}
      className={`bg-white dark:bg-gray-700 p-3 rounded-lg shadow hover:shadow-md transition-shadow duration-200 cursor-pointer mb-2 ${
        snapshot.isDragging ? "opacity-70" : ""
      }`}
      onClick={openTaskModal}
    >
      <div className="flex justify-between items-start mb-2">
        <h3 className="font-semibold text-gray-900 dark:text-white text-sm">{task.title}</h3>
        <button
          onClick={handleDelete}
          className="text-gray-400 hover:text-red-500 dark:text-gray-500 dark:hover:text-red-400 transition-colors duration-200"
        >
          <Trash2 size={14} />
        </button>
      </div>
      <p className="text-xs text-gray-600 dark:text-gray-300 line-clamp-2 mb-2">{task.description}</p>
      <div className="flex justify-between items-center">
        <span className={`text-xs px-2 py-1 rounded-full ${priorityColors[task.priority]} font-medium`}>
          {task.priority}
        </span>
        

        {task.assignee && <span className="text-xs text-gray-500 dark:text-gray-400 font-medium">{task.assignee}</span>}
      </div>
    </div>
  )
}

