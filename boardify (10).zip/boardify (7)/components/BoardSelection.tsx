"use client";

import { useState, useEffect } from "react";
import { auth, db } from "../lib/firebase";
import { collection, query, where, getDocs, deleteDoc, doc } from "firebase/firestore";
import { useRouter } from "next/navigation";
import { Plus, Layout, LogOut, Trash2, CheckSquare, Square } from "lucide-react";

interface Board {
  id: string;
  name: string;
  createdAt: Date;
}

export default function BoardSelection() {
  const [boards, setBoards] = useState<Board[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectionMode, setSelectionMode] = useState(false);
  const [selectedBoards, setSelectedBoards] = useState<string[]>([]);
  const router = useRouter();

  useEffect(() => {
    const fetchBoards = async () => {
      const user = auth.currentUser;
      if (!user) return;

      try {
        const boardsRef = collection(db, "boards");
        const q = query(boardsRef, where("userId", "==", user.uid));
        const querySnapshot = await getDocs(q);
        const boardsData = querySnapshot.docs.map((doc) => ({
          id: doc.id,
          ...doc.data(),
        })) as Board[];
        setBoards(boardsData);
      } catch (error) {
        console.error("Error fetching boards:", error);
      } finally {
        setLoading(false);
      }
    };

    fetchBoards();
  }, []);

  const toggleSelection = (boardId: string) => {
    setSelectedBoards((prev) =>
      prev.includes(boardId) ? prev.filter((id) => id !== boardId) : [...prev, boardId]
    );
  };

  const selectAllBoards = () => {
    setSelectedBoards(boards.map((board) => board.id));
  };

  const clearSelection = () => {
    setSelectedBoards([]);
  };

  const deleteSelectedBoards = async () => {
    if (selectedBoards.length === 0) return;
    if (!window.confirm("Are you sure you want to delete selected boards?")) return;

    try {
      await Promise.all(selectedBoards.map((id) => deleteDoc(doc(db, "boards", id))));
      setBoards((prev) => prev.filter((board) => !selectedBoards.includes(board.id)));
      setSelectedBoards([]);
      setSelectionMode(false);
    } catch (error) {
      console.error("Error deleting boards:", error);
    }
  };

  const handleSignOut = async () => {
    try {
      await auth.signOut();
      router.push("/");
    } catch (error) {
      console.error("Error signing out:", error);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-indigo-50 to-purple-50 dark:from-gray-900 dark:to-gray-800">
      <div className="container mx-auto px-4 py-8">
        <div className="max-w-4xl mx-auto">
          {/* Header */}
          <div className="flex justify-between items-center mb-8">
            <h1 className="text-3xl md:text-4xl font-bold text-gray-900 dark:text-white">
              Welcome, {auth.currentUser?.displayName}
            </h1>
            <button
              onClick={handleSignOut}
              className="flex items-center px-4 py-2 text-gray-700 dark:text-gray-200 hover:text-red-500 dark:hover:text-red-400"
            >
              <LogOut className="w-5 h-5 mr-2" />
              <span className="hidden sm:inline">Sign Out</span>
            </button>
          </div>

          {/* Create New Board Button */}
          <button
            onClick={() => router.push("/board/new")}
            className="w-full mb-8 p-6 bg-white dark:bg-gray-800 rounded-xl shadow-md hover:shadow-lg transition-shadow duration-200 flex items-center justify-center group"
          >
            <Plus className="w-6 h-6 mr-2 text-indigo-500 group-hover:scale-110 transition-transform duration-200" />
            <span className="text-xl font-semibold text-gray-900 dark:text-white">Create New Board</span>
          </button>

          {/* Selection Mode Actions */}
          <div className="flex justify-between items-center mb-4">
            <div className="flex space-x-3">
              <button
                onClick={() => setSelectionMode(!selectionMode)}
                className="px-4 py-2 rounded-lg text-white bg-blue-600 hover:bg-blue-700 transition"
              >
                {selectionMode ? "Cancel Selection" : "Select Boards"}
              </button>
              {selectionMode && (
                <>
                  <button
                    onClick={selectAllBoards}
                    className="px-4 py-2 rounded-lg bg-green-500 text-white hover:bg-green-600 transition"
                  >
                    Select All
                  </button>
                  <button
                    onClick={clearSelection}
                    className="px-4 py-2 rounded-lg bg-gray-500 text-white hover:bg-gray-600 transition"
                  >
                    Clear Selection
                  </button>
                </>
              )}
            </div>
            {selectionMode && selectedBoards.length > 0 && (
              <button
                onClick={deleteSelectedBoards}
                className="px-4 py-2 rounded-lg bg-red-500 text-white hover:bg-red-600 transition"
              >
                <Trash2 className="inline-block mr-2" /> Delete Selected
              </button>
            )}
          </div>

          {/* Recent Boards */}
          <div className="space-y-4">
            <h2 className="text-xl font-semibold text-gray-900 dark:text-white mb-4">Recent Boards</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {boards.map((board) => (
                <button
                  key={board.id}
                  onClick={() => (selectionMode ? toggleSelection(board.id) : router.push(`/board/${board.id}`))}
                  className="p-6 bg-white dark:bg-gray-800 rounded-xl shadow-md hover:shadow-lg transition-all duration-200 text-left group flex justify-between items-center"
                >
                  <div className="flex items-start">
                    <Layout className="w-5 h-5 mr-3 text-indigo-500 group-hover:scale-110 transition-transform duration-200" />
                    <div>
                      <h3 className="font-semibold text-gray-900 dark:text-white mb-1">{board.name}</h3>
                      <p className="text-sm text-gray-500 dark:text-gray-400">
                        Created {new Date(board.createdAt).toLocaleDateString()}
                      </p>
                    </div>
                  </div>
                  {selectionMode && (
                    <button>
                      {selectedBoards.includes(board.id) ? <CheckSquare className="text-blue-500" /> : <Square className="text-gray-500" />}
                    </button>
                  )}
                </button>
              ))}
            </div>

            {boards.length === 0 && !loading && (
              <div className="text-center py-12">
                <p className="text-gray-500 dark:text-gray-400">No boards yet. Create your first board!</p>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
