"use client"

import { useState, useEffect } from "react"
import { DragDropContext, Droppable, Draggable } from "react-beautiful-dnd"
import { auth } from "../lib/firebase"
import { doc, onSnapshot, updateDoc, deleteDoc, arrayUnion, arrayRemove } from "firebase/firestore"
import { Plus, Loader2, Settings } from "lucide-react"
import { useRouter } from "next/navigation"
import TaskModal from "./TaskModal"
import Column from "./Column"
import BoardSettingsModal from "./BoardSettingsModal"
import { collection, addDoc, serverTimestamp } from "firebase/firestore";
import { db } from "../lib/firebase"; // Ensure Firebase is correctly imported
import { query, where, getDocs, getDoc } from "firebase/firestore";
import ManageMembersModal from "./ManageMembersModal"; // Import the modal



const addUserToBoard = async (email: string, boardId: string) => {
  const q = query(collection(db, "users"), where("email", "==", email));
  const userSnapshot = await getDocs(q);

  if (!userSnapshot.empty) {
    const userDoc = userSnapshot.docs[0];

    const boardRef = doc(db, "boards", boardId);
    const boardSnap = await getDoc(boardRef);

    if (boardSnap.exists()) {
      const existingMembers = boardSnap.data().members || [];
      if (existingMembers.includes(userDoc.id)) {
        alert("User is already a member!");
        return;
      }
    }

    await updateDoc(boardRef, {
      members: arrayUnion(userDoc.id),
    });

    alert("User added!");
  } else {
    alert("User not found!");
  }
};

const removeMember = async (userId: string, boardId: string) => {
  await updateDoc(doc(db, "boards", boardId), {
    members: arrayRemove(userId),
  });
  alert("User removed!");
};


// Call the function where needed
// addUserToBoard(email, boardId);

const sendNotification = async (userId: string, taskId: string, message: string) => {
  try {
    await addDoc(collection(db, "notifications"), {
      userId,
      taskId,
      message,
      timestamp: serverTimestamp(),
      read: false,
    });
  } catch (error) {
    console.error("Error sending notification:", error);
  }
};

interface Task {
  id: string; // Ensure this is always a string (remove `| undefined`)
  title: string;
  description: string;
  priority: "low" | "medium" | "high";
  assignee: string;
}

interface TaskModalProps {
  isOpen: boolean
  onClose: () => void
  onSave: (task: Task) => void | Promise<void>;
  task?: Task | null
  columnId: string | null
  boardId: string
}

interface Column {
  id: string
  title: string
  tasks: Task[]
  color: string
}

interface KanbanBoardProps {
  boardId: string
}

export default function KanbanBoard({ boardId }: KanbanBoardProps) {
  const [columns, setColumns] = useState<Column[]>([])
  const [isTaskModalOpen, setIsTaskModalOpen] = useState(false)
  const [isBoardSettingsOpen, setIsBoardSettingsOpen] = useState(false)
  const [currentColumnId, setCurrentColumnId] = useState<string | null>(null)
  const [members, setMembers] = useState<string[]>([]);

  const [currentTask, setCurrentTask] = useState<Task | null>(null)

  const [isMembersModalOpen, setIsMembersModalOpen] = useState(false);
  const [boardName, setBoardName] = useState("")
  const [loading, setLoading] = useState(true)
  const [backgroundColor, setBackgroundColor] = useState("#f3f4f6")
  const [backgroundImage, setBackgroundImage] = useState("")
  const router = useRouter()

  useEffect(() => {
    const user = auth.currentUser
    if (!user) {
      router.push("/")
      return
    }

    const boardRef = doc(db, "boards", boardId)
    const unsubscribe = onSnapshot(boardRef, (doc) => {
      try {
        if (doc.exists() && doc.data().userId === user.uid) {
          const boardData = doc.data()
          setBoardName(boardData.name)
          setBackgroundColor(boardData.backgroundColor || "#f3f4f6")
          setBackgroundImage(boardData.backgroundImage || "")
          const columnsData = boardData.columns || []
          if (Array.isArray(columnsData)) {
            setColumns(
              columnsData.map((col: any) => ({
                ...col,
                tasks: Array.isArray(col.tasks) ? col.tasks : [],
                color: col.color || "#4F46E5", // Default color if not set
              })),
            )
          } else {
            console.error("Columns data is not an array:", columnsData)
            setColumns([])
          }
        } else {
          router.push("/")
        }
      } catch (error) {
        console.error("Error processing board data:", error)
        setColumns([])
      } finally {
        setLoading(false)
      }
    })

    return () => unsubscribe()
  }, [boardId, router])

  const updateFirestore = async (newColumns: Column[]) => {
    const user = auth.currentUser
    if (!user) return

    const boardRef = doc(db, "boards", boardId)
    await updateDoc(boardRef, { columns: newColumns })
  }

  const onDragEnd = async (result: any) => {
    const { destination, source, draggableId, type } = result

    if (!destination) return

    if (destination.droppableId === source.droppableId && destination.index === source.index) {
      return
    }

    if (type === "column") {
      const newColumns = Array.from(columns)
      const [removedColumn] = newColumns.splice(source.index, 1)
      newColumns.splice(destination.index, 0, removedColumn)
      setColumns(newColumns)
      await updateFirestore(newColumns)
      return
    }

    const startColumn = columns.find((col) => col.id === source.droppableId)
    const finishColumn = columns.find((col) => col.id === destination.droppableId)

    if (!startColumn || !finishColumn) return

    if (startColumn === finishColumn) {
      const newTasks = Array.from(startColumn.tasks)
      const [reorderedItem] = newTasks.splice(source.index, 1)
      newTasks.splice(destination.index, 0, reorderedItem)

      const newColumn = {
        ...startColumn,
        tasks: newTasks,
      }

      const newColumns = columns.map((col) => (col.id === newColumn.id ? newColumn : col))

      setColumns(newColumns)
      await updateFirestore(newColumns)
    } else {
      const startTasks = Array.from(startColumn.tasks)
      const [movedItem] = startTasks.splice(source.index, 1)
      const newStartColumn = {
        ...startColumn,
        tasks: startTasks,
      }

      const finishTasks = Array.from(finishColumn.tasks)
      finishTasks.splice(destination.index, 0, movedItem)
      const newFinishColumn = {
        ...finishColumn,
        tasks: finishTasks,
      }

      const newColumns = columns.map((col) =>
        col.id === newStartColumn.id ? newStartColumn : col.id === newFinishColumn.id ? newFinishColumn : col,
      )

      setColumns(newColumns)
      await updateFirestore(newColumns)
    }
  }

  const addColumn = async () => {
    const newColumnTitle = prompt("Enter column title:")
    if (newColumnTitle) {
      const newColumn: Column = {
        id: Date.now().toString(),
        title: newColumnTitle,
        tasks: [],
        color: "#4F46E5", // Default color
      }
      const updatedColumns = [...columns, newColumn]
      setColumns(updatedColumns)
      await updateFirestore(updatedColumns)
    }
  }

  const updateColumn = async (columnId: string, newTitle: string, newColor: string) => {
    const updatedColumns = columns.map((col) =>
      col.id === columnId ? { ...col, title: newTitle, color: newColor } : col,
    )
    setColumns(updatedColumns)
    await updateFirestore(updatedColumns)
  }

  const deleteColumn = async (columnId: string) => {
    const updatedColumns = columns.filter((col) => col.id !== columnId)
    setColumns(updatedColumns)
    await updateFirestore(updatedColumns)
  }

  const openTaskModal = (columnId: string, task: Task | null = null) => {
    setCurrentColumnId(columnId)
    setCurrentTask(task)
    setIsTaskModalOpen(true)
  }

  const closeTaskModal = () => {
    setIsTaskModalOpen(false)
    setCurrentColumnId(null)
    setCurrentTask(null)
  }

  const addOrUpdateTask = async (task: Task) => {
    if (!currentColumnId) return;
  
    const updatedColumns = columns.map((col) => {
      if (col.id === currentColumnId) {
        if (task.id) {
          // Update existing task
          return {
            ...col,
            tasks: col.tasks.map((t) =>
              t.id === task.id ? { ...task, updatedBy: auth.currentUser?.uid } : t
            ),
          };
        } else {
          // Add new task
          const newTask = {
            ...task,
            id: Date.now().toString(),
            createdBy: auth.currentUser?.uid,
          };
          return { ...col, tasks: [...col.tasks, newTask] };
        }
      }
      return col;
    });
  
    setColumns(updatedColumns);
    await updateFirestore(updatedColumns);
  
    // Send notification to assignee
    if (task.assignee) {
      const message = task.id
        ? "A task assigned to you has been updated."
        : "You have been assigned a new task.";
      await sendNotification(task.assignee, task.id || "", message);
    }
  
    closeTaskModal();
  };
  
  useEffect(() => {
    const boardRef = doc(db, "boards", boardId);
    const unsubscribe = onSnapshot(boardRef, (boardSnap) => {
      if (boardSnap.exists()) {
        setMembers(boardSnap.data().members || []);
      }
    });
  
    return () => unsubscribe(); // Clean up the listener
  }, [boardId]);
  
  
  
  const deleteTask = async (columnId: string, taskId: string) => {
    const updatedColumns = columns.map((col) => {
      if (col.id === columnId) {
        return {
          ...col,
          tasks: col.tasks.filter((task) => task.id !== taskId),
        }
      }
      return col
    })

    setColumns(updatedColumns)
    await updateFirestore(updatedColumns)
  }

  const updateBoard = async (newName: string, newBackgroundColor: string, newBackgroundImage: string) => {
    const boardRef = doc(db, "boards", boardId)
    await updateDoc(boardRef, {
      name: newName,
      backgroundColor: newBackgroundColor,
      backgroundImage: newBackgroundImage,
    })
    setBoardName(newName)
    setBackgroundColor(newBackgroundColor)
    setBackgroundImage(newBackgroundImage)
  }

  const deleteBoard = async () => {
    if (confirm("Are you sure you want to delete this board? This action cannot be undone.")) {
      await deleteDoc(doc(db, "boards", boardId))
      router.push("/")
    }
  }

  if (loading) {
    return (
      <div className="flex items-center justify-center h-[calc(100vh-120px)]">
        <Loader2 className="w-8 h-8 animate-spin text-indigo-500" />
      </div>
    )
  }

  const boardStyle = {
    backgroundImage: backgroundImage ? `url(${backgroundImage})` : "none",
    backgroundColor: backgroundImage ? "transparent" : backgroundColor,
    backgroundSize: "cover",
    backgroundPosition: "center",
  }

  return (
    <div className="h-[calc(100vh-120px)] overflow-hidden" style={boardStyle}>
      <div className="flex justify-between items-center mb-4 p-4 bg-white bg-opacity-75 dark:bg-gray-800 dark:bg-opacity-75 rounded-lg shadow-md">
       
        <div className="flex space-x-2">
          <button
            onClick={addColumn}
            className="flex items-center px-3 py-2 bg-indigo-500 text-white rounded-md hover:bg-indigo-600 transition-colors duration-200 text-sm font-medium"
          >
            <Plus className="w-4 h-4 mr-1" />
            Add Column
          </button>
          <button
  onClick={() => alert("Feature coming soon!")}
  className="px-3 py-2 bg-green-500 text-white rounded-md hover:bg-green-600 text-sm font-medium"
>
  Manage Members
</button>


          <button
            onClick={() => setIsBoardSettingsOpen(true)}
            className="flex items-center px-3 py-2 bg-gray-200 text-gray-700 dark:bg-gray-700 dark:text-gray-200 rounded-md hover:bg-gray-300 dark:hover:bg-gray-600 transition-colors duration-200 text-sm font-medium"
          >
            <Settings className="w-4 h-4 mr-1" />
            Board Settings
          </button>
        </div>
      </div>

      <DragDropContext onDragEnd={onDragEnd}>
        <Droppable droppableId="board" type="column" direction="horizontal">
          {(provided) => (
            <div
              {...provided.droppableProps}
              ref={provided.innerRef}
              className="flex space-x-4 p-4 overflow-x-auto h-[calc(100%-80px)]"
            >
              {columns.map((column, index) => (
                <Draggable key={column.id} draggableId={column.id} index={index}>
                  {(provided) => (
                    <div ref={provided.innerRef} {...provided.draggableProps} className="w-80 flex-shrink-0">
                      <Column
                        column={column}
                        openTaskModal={openTaskModal}
                        deleteTask={deleteTask}
                        updateColumn={updateColumn}
                        deleteColumn={deleteColumn}
                        dragHandleProps={provided.dragHandleProps}
                      />
                    </div>
                  )}
                </Draggable>
              ))}
              {provided.placeholder}
            </div>
          )}
        </Droppable>
      </DragDropContext>

      <TaskModal
        isOpen={isTaskModalOpen}
        onClose={closeTaskModal}
        onSave={addOrUpdateTask}
        task={currentTask}
        columnId={currentColumnId}
        boardId={boardId}
      />

      <BoardSettingsModal
        isOpen={isBoardSettingsOpen}
        onClose={() => setIsBoardSettingsOpen(false)}
        boardName={boardName}
        backgroundColor={backgroundColor}
        backgroundImage={backgroundImage}
        onUpdateBoard={updateBoard}
        onDeleteBoard={deleteBoard}
      />
    </div>
  )
}

