"use client"

import type React from "react"

import { useState } from "react"
import { X } from "lucide-react"

interface BoardSettingsModalProps {
  isOpen: boolean
  onClose: () => void
  boardName: string
  backgroundColor: string
  backgroundImage: string
  onUpdateBoard: (newName: string, newBackgroundColor: string, newBackgroundImage: string) => void
  onDeleteBoard: () => void
}

export default function BoardSettingsModal({
  isOpen,
  onClose,
  boardName,
  backgroundColor,
  backgroundImage,
  onUpdateBoard,
  onDeleteBoard,
}: BoardSettingsModalProps) {
  const [newBoardName, setNewBoardName] = useState(boardName)
  const [newBackgroundColor, setNewBackgroundColor] = useState(backgroundColor)
  const [newBackgroundImage, setNewBackgroundImage] = useState(backgroundImage)

  if (!isOpen) return null

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    onUpdateBoard(newBoardName, newBackgroundColor, newBackgroundImage)
    onClose()
  }

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (file) {
      const reader = new FileReader()
      reader.onloadend = () => {
        setNewBackgroundImage(reader.result as string)
      }
      reader.readAsDataURL(file)
    }
  }

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
      <div className="bg-white dark:bg-gray-800 rounded-lg w-full max-w-md shadow-xl">
        <div className="flex justify-between items-center p-6 border-b dark:border-gray-700">
          <h2 className="text-xl font-semibold text-gray-900 dark:text-white">Board Settings</h2>
          <button
            onClick={onClose}
            className="text-gray-500 hover:text-gray-700 dark:text-gray-400 dark:hover:text-gray-200"
          >
            <X size={24} />
          </button>
        </div>
        <form onSubmit={handleSubmit} className="p-6 space-y-6">
          <div>
            <label htmlFor="boardName" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
              Board Name
            </label>
            <input
              type="text"
              id="boardName"
              value={newBoardName}
              onChange={(e) => setNewBoardName(e.target.value)}
              className="w-full px-3 py-2 rounded-md border border-gray-300 shadow-sm focus:ring-indigo-500 focus:border-indigo-500 dark:bg-gray-700 dark:border-gray-600 dark:text-white"
              required
            />
          </div>
          <div>
            <label
              htmlFor="backgroundColor"
              className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1"
            >
              Background Color
            </label>
            <div className="flex items-center">
              <input
                type="color"
                id="backgroundColor"
                value={newBackgroundColor}
                onChange={(e) => setNewBackgroundColor(e.target.value)}
                className="w-10 h-10 rounded-md border border-gray-300 shadow-sm focus:ring-indigo-500 focus:border-indigo-500"
              />
              <span className="ml-2 text-sm text-gray-600 dark:text-gray-400">{newBackgroundColor}</span>
            </div>
          </div>
          <div>
            <label
              htmlFor="backgroundImage"
              className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1"
            >
              Background Image URL
            </label>
            <input
              type="text"
              id="backgroundImage"
              value={newBackgroundImage}
              onChange={(e) => setNewBackgroundImage(e.target.value)}
              className="w-full px-3 py-2 rounded-md border border-gray-300 shadow-sm focus:ring-indigo-500 focus:border-indigo-500 dark:bg-gray-700 dark:border-gray-600 dark:text-white"
              placeholder="Enter image URL"
            />
          </div>
          <div>
            <label
              htmlFor="backgroundImageUpload"
              className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1"
            >
              Upload Background Image
            </label>
            <input
              type="file"
              id="backgroundImageUpload"
              accept="image/*"
              onChange={handleImageUpload}
              className="w-full text-sm text-gray-500 file:mr-4 file:py-2 file:px-4 file:rounded-full file:border-0 file:text-sm file:font-semibold file:bg-indigo-50 file:text-indigo-700 hover:file:bg-indigo-100 dark:file:bg-gray-700 dark:file:text-gray-200 dark:hover:file:bg-gray-600"
            />
          </div>
          <div className="flex justify-between pt-4">
            <button
              type="submit"
              className="px-4 py-2 bg-indigo-600 text-white rounded-md hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 transition-colors duration-200"
            >
              Update Board
            </button>
            <button
              type="button"
              onClick={onDeleteBoard}
              className="px-4 py-2 bg-red-600 text-white rounded-md hover:bg-red-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-red-500 transition-colors duration-200"
            >
              Delete Board
            </button>
          </div>
        </form>
      </div>
    </div>
  )
}

