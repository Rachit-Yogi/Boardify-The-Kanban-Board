"use client";

import { useState, useEffect } from "react";
import { auth, db } from "../lib/firebase";
import { type User, signOut } from "firebase/auth";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { Bell } from "lucide-react";
import { collection, query, where, onSnapshot, updateDoc, doc, getDoc } from "firebase/firestore";

export default function Header() {
  const [user, setUser] = useState<User | null>(auth.currentUser);
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [notifications, setNotifications] = useState<{ id: string; message: string; taskId?: string; sender?: string }[]>([]);
  const [isNotifOpen, setIsNotifOpen] = useState(false);
  const router = useRouter();
  const [isMembersModalOpen, setIsMembersModalOpen] = useState(false);


  useEffect(() => {
    if (!user) return;

    const q = query(collection(db, "notifications"), where("userId", "==", user.uid), where("read", "==", false));

    const unsubscribe = onSnapshot(q, async (snapshot) => {
      const notifs = await Promise.all(
        snapshot.docs.map(async (docSnap) => {
          const data = docSnap.data();
          
          // Fetch sender's name from Firestore (if available)
          let senderName = "Someone";
          if (data.senderId) {
            const senderDoc = await getDoc(doc(db, "users", data.senderId));
            if (senderDoc.exists()) {
              senderName = senderDoc.data().displayName || "Someone";
            }
          }

          return {
            id: docSnap.id,
            message: `${senderName}: ${data.message}`,
            taskId: data.taskId || null,
            sender: senderName,
          };
        })
      );
      setNotifications(notifs);
    });

    return () => unsubscribe();
  }, [user]);

  const markAsRead = async (notifId: string) => {
    await updateDoc(doc(db, "notifications", notifId), { read: true });
  };

  const markAllAsRead = async () => {
    const batchUpdates = notifications.map((notif) =>
      updateDoc(doc(db, "notifications", notif.id), { read: true })
    );
    await Promise.all(batchUpdates);
    setNotifications([]); // Clear notifications UI
  };

  const handleNotificationClick = (taskId?: string, notifId?: string) => {
    if (notifId) markAsRead(notifId);
    if (taskId) router.push(`/task/${taskId}`); // Redirect to the task page
  };

  const handleSignOut = async () => {
    try {
      await signOut(auth);
      router.push("/signin");
    } catch (error) {
      console.error("Error signing out:", error);
    }
  };

  return (
    <header className="bg-primary text-primary-foreground shadow-lg">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between h-16">
          <div className="flex items-center">
            <Link href="/" className="text-2xl font-bold">
              Boardify
            </Link>
            <nav className="ml-6 space-x-4">
              <Link href="/boards" className="hover:text-secondary-foreground">
                My Boards
              </Link>
            </nav>
          </div>
          <div className="flex items-center space-x-4">
            {user && (
              <div className="relative">
                {/* Notification Bell */}
                <button className="relative" onClick={() => setIsNotifOpen(!isNotifOpen)}>
                  <Bell className="w-6 h-6 text-gray-600" />
                  {notifications.length > 0 && (
                    <span className="absolute top-0 right-0 bg-red-500 text-white text-xs rounded-full w-4 h-4 flex items-center justify-center">
                      {notifications.length}
                    </span>
                  )}
                </button>

                {/* Notification Dropdown */}
                {isNotifOpen && (
                  <div className="absolute right-0 mt-2 w-64 bg-white shadow-lg rounded-md p-2 z-50">
                    <div className="flex justify-between items-center px-2">
                      <h3 className="text-sm font-semibold">Notifications</h3>
                      <button onClick={markAllAsRead} className="text-xs text-blue-500 hover:underline">
                        Mark All as Read
                      </button>
                    </div>
                    <div className="mt-2 max-h-60 overflow-auto">
                      {notifications.length > 0 ? (
                        notifications.map((notif) => (
                          <div
                            key={notif.id}
                            className="p-2 border-b hover:bg-gray-100 cursor-pointer text-sm"
                            onClick={() => handleNotificationClick(notif.taskId, notif.id)}
                          >
                            {notif.message}
                          </div>
                        ))
                      ) : (
                        <p className="text-gray-500 text-sm text-center py-2">No new notifications</p>
                      )}
                    </div>
                  </div>
                )}
              </div>
            )}

            {/* User Profile Dropdown */}
            {user && (
              <div className="relative">
                <button
                  className="flex items-center space-x-2 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary"
                  onClick={() => setIsMenuOpen(!isMenuOpen)}
                >
                  <img className="h-8 w-8 rounded-full" src={user.photoURL || undefined} alt="" />
                  <span>{user.displayName}</span>
                </button>

                {isMenuOpen && (
                  <div className="absolute right-0 mt-2 w-48 rounded-md shadow-lg bg-white dark:bg-gray-800 ring-1 ring-black ring-opacity-5">
                    <div className="py-1" role="menu" aria-orientation="vertical" aria-labelledby="user-menu">
                      <button
                        onClick={handleSignOut}
                        className="block w-full text-left px-4 py-2 text-sm text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-700"
                        role="menuitem"
                      >
                        Sign out
                      </button>
                    </div>
                  </div>
                )}
              </div>
            )}
          </div>
        </div>
      </div>
    </header>
  );
}
