import { useState } from "react";
import { collection, doc, updateDoc, getDoc, arrayUnion, arrayRemove } from "firebase/firestore";
import { db } from "../lib/firebase";

interface ManageMembersModalProps {
  boardId: string;
  onClose: () => void;
}

export default function ManageMembersModal({ boardId, onClose }: ManageMembersModalProps) {
  const [email, setEmail] = useState("");

  const addMember = async () => {
    if (!email) return;
    const userRef = collection(db, "users"); // Assuming a users collection exists
    const userSnapshot = await getDoc(doc(userRef, email));

    if (userSnapshot.exists()) {
      await updateDoc(doc(db, "boards", boardId), {
        members: arrayUnion(userSnapshot.id),
      });
      alert("User added!");
    } else {
      alert("User not found!");
    }
  };

  const removeMember = async (userId: string) => {
    await updateDoc(doc(db, "boards", boardId), {
      members: arrayRemove(userId),
    });
    alert("User removed!");
  };

  return (
    <div className="modal">
      <h2>Manage Members</h2>
      <input type="email" placeholder="Enter user email" value={email} onChange={(e) => setEmail(e.target.value)} />
      <button onClick={addMember}>Add Member</button>
      <button onClick={onClose}>Close</button>
    </div>
  );
}
