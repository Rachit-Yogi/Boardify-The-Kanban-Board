"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { db } from "../lib/firebase"
import { doc, updateDoc, getDoc } from "firebase/firestore"
import { X } from "lucide-react"
import { collection, addDoc, serverTimestamp } from "firebase/firestore";

interface Task {
  id: string; // Ensure this is always a string (remove `| undefined`)
  title: string;
  description: string;
  priority: "low" | "medium" | "high";
  assignee: string;
}

interface TaskModalProps {
  isOpen: boolean
  onClose: () => void
  onSave: (task: Task) => void | Promise<void>;
  task?: Task | null
  columnId: string | null
  boardId: string
}

export default function TaskModal({ isOpen, onClose, onSave, task, columnId, boardId }: TaskModalProps) {
  const [title, setTitle] = useState(task?.title || "")
  const [description, setDescription] = useState(task?.description || "")
  const [priority, setPriority] = useState<"low" | "medium" | "high">(task?.priority || "medium")
  const [assignee, setAssignee] = useState(task?.assignee || "")

  useEffect(() => {
    if (isOpen) {
      if (task) {
        setTitle(task.title)
        setDescription(task.description)
        setPriority(task.priority)
        setAssignee(task.assignee)
      } else {
        // Clear inputs when creating a new task
        setTitle("")
        setDescription("")
        setPriority("medium")
        setAssignee("")
      }
    }
  }, [isOpen, task])

  const sendNotification = async (userId: string, taskId: string, message: string) => {
    try {
      await addDoc(collection(db, "notifications"), {
        userId,
        taskId,
        message,
        timestamp: serverTimestamp(),
        read: false,
      });
      console.log("Notification sent!");
    } catch (error) {
      console.error("Error sending notification:", error);
    }
  };


  const assignTask = async (taskId: string, assignedUserId: string) => {
    try {
      await updateDoc(doc(db, "tasks", taskId), { assignedTo: assignedUserId });

      // Send notification
      await sendNotification(assignedUserId, taskId, "You have been assigned a new task.");
    } catch (error) {
      console.error("Error assigning task:", error);
    }
  };


  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    const newTask: Task = {
      id: task?.id || Date.now().toString(),
      title,
      description,
      priority,
      assignee,
    }

    onSave(newTask)


    if (!task?.id && columnId) {
      try {
        const boardRef = doc(db, "boards", boardId)
        const boardDoc = await getDoc(boardRef)

        if (boardDoc.exists()) {
          const columns = boardDoc.data().columns || []
          const updatedColumns = columns.map((col: any) => {
            if (col.id === columnId) {
              return {
                ...col,
                tasks: [...(col.tasks || []), newTask],
              }
            }
            return col
          })

          await updateDoc(boardRef, { columns: updatedColumns })
        }
      } catch (error) {
        console.error("Error adding new task:", error)
      }
    }

    onClose()
  }

  if (!isOpen) return null

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
      <div className="bg-white dark:bg-gray-800 rounded-lg w-full max-w-md">
        <div className="flex justify-between items-center p-4 border-b dark:border-gray-700">
          <h2 className="text-xl font-semibold">{task ? "Edit Task" : "Create Task"}</h2>
          <button
            onClick={onClose}
            className="text-gray-500 hover:text-gray-700 dark:text-gray-400 dark:hover:text-gray-200"
          >
            <X size={24} />
          </button>
        </div>
        <form onSubmit={handleSubmit} className="p-4 space-y-4">
          <div>
            <label htmlFor="title" className="block text-sm font-medium text-gray-700 dark:text-gray-300">
              Title
            </label>
            <input
              type="text"
              id="title"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-300 focus:ring focus:ring-indigo-200 focus:ring-opacity-50 dark:bg-gray-700 dark:border-gray-600 dark:text-white"
              required
            />
          </div>
          <div>
            <label htmlFor="description" className="block text-sm font-medium text-gray-700 dark:text-gray-300">
              Description
            </label>
            <textarea
              id="description"
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-300 focus:ring focus:ring-indigo-200 focus:ring-opacity-50 dark:bg-gray-700 dark:border-gray-600 dark:text-white"
              rows={3}
            ></textarea>
          </div>
          <div>
            <label htmlFor="priority" className="block text-sm font-medium text-gray-700 dark:text-gray-300">
              Priority
            </label>
            <select
              id="priority"
              value={priority}
              onChange={(e) => setPriority(e.target.value as "low" | "medium" | "high")}
              className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-300 focus:ring focus:ring-indigo-200 focus:ring-opacity-50 dark:bg-gray-700 dark:border-gray-600 dark:text-white"
            >
              <option value="low">Low</option>
              <option value="medium">Medium</option>
              <option value="high">High</option>
            </select>
          </div>
          <div>
            <label htmlFor="assignee" className="block text-sm font-medium text-gray-700 dark:text-gray-300">
              Assignee
            </label>
            <input
              type="text"
              id="assignee"
              value={assignee}
              onChange={(e) => setAssignee(e.target.value)}
              className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-300 focus:ring focus:ring-indigo-200 focus:ring-opacity-50 dark:bg-gray-700 dark:border-gray-600 dark:text-white"
            />
          </div>
          <div className="flex justify-end">
            <button
              type="submit"
              className="px-4 py-2 bg-indigo-600 text-white rounded-md hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500"
            >
              {task ? "Update Task" : "Create Task"}
            </button>
          </div>
        </form>
      </div>
    </div>
  )
}

