import type { Config } from "tailwindcss"

const config: Config = {
  darkMode: "class", // Enables dark mode
  content: [
    "./pages/**/*.{js,ts,jsx,tsx,mdx}",
    "./components/**/*.{js,ts,jsx,tsx,mdx}",
    "./app/**/*.{js,ts,jsx,tsx,mdx}",
    "*.{js,ts,jsx,tsx,mdx}",
  ],
  theme: {
    extend: {
      fontFamily: {
        sans: ["Inter", "sans-serif"],
      },
      colors: {
        primary: "#4F46E5", // Indigo Blue
        secondary: "#6366F1", // Lighter Blue
        accent: "#14B8A6", // Teal Green
        background: "#F9FAFB", // Light mode BG
        foreground: "#111827", // Dark mode text
        dark: {
          bg: "#1F2937", // Dark mode background
          text: "#E5E7EB", // Dark mode text
          card: "#374151", // Darker card background
        },
      },
      borderRadius: {
        lg: "12px",
        md: "8px",
        sm: "6px",
      },
    },
  },
  plugins: [],
}

export default config

