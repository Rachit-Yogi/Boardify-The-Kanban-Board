"use client"

import { useEffect, useState } from "react"
import { useRouter } from "next/navigation"
import { auth, db } from "../../../lib/firebase"
import { doc, getDoc } from "firebase/firestore"
import KanbanBoard from "../../../components/KanbanBoard"
import { ArrowLeft, Loader2 } from "lucide-react"

interface BoardPageProps {
  params: {
    id: string
  }
}

export default function BoardPage({ params }: BoardPageProps) {
  const [boardName, setBoardName] = useState("")
  const [loading, setLoading] = useState(true)
  const router = useRouter()

  useEffect(() => {
    const fetchBoard = async () => {
      const user = auth.currentUser
      if (!user) {
        router.push("/")
        return
      }

      try {
        const boardRef = doc(db, "boards", params.id)
        const boardSnap = await getDoc(boardRef)

        if (boardSnap.exists() && boardSnap.data().userId === user.uid) {
          setBoardName(boardSnap.data().name)
        } else {
          router.push("/")
        }
      } catch (error) {
        console.error("Error fetching board:", error)
        router.push("/")
      } finally {
        setLoading(false)
      }
    }

    fetchBoard()
  }, [params.id, router])

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-indigo-50 to-purple-50 dark:from-gray-900 dark:to-gray-800">
        <Loader2 className="w-8 h-8 animate-spin text-indigo-500" />
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-indigo-50 to-purple-50 dark:from-gray-900 dark:to-gray-800">
      <div className="container mx-auto px-4 py-4">
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center">
            <button
              onClick={() => router.push("/")}
              className="mr-4 text-gray-600 dark:text-gray-300 hover:text-gray-900 dark:hover:text-white"
            >
              <ArrowLeft className="w-5 h-5" />
            </button>
            <h1 className="text-2xl font-bold text-gray-900 dark:text-white">{boardName}</h1>
          </div>
        </div>
        <KanbanBoard boardId={params.id} />
      </div>
    </div>
  )
}

