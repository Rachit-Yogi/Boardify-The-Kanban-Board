"use client"

import type React from "react"

import { useState } from "react"
import { auth, db } from "../../../lib/firebase"
import { collection, addDoc } from "firebase/firestore"
import { useRouter } from "next/navigation"
import { Layout, ArrowLeft } from "lucide-react"

export default function NewBoardPage() {
  const [boardName, setBoardName] = useState("")
  const [loading, setLoading] = useState(false)
  const router = useRouter()

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    const user = auth.currentUser
    if (!user) {
      router.push("/")
      return
    }

    setLoading(true)
    try {
      const docRef = await addDoc(collection(db, "boards"), {
        name: boardName,
        userId: user.uid,
        createdAt: new Date().toISOString(), // Store as ISO string
        columns: [
          { id: "backlog", title: "Backlog", tasks: [] },
          { id: "todo", title: "To Do", tasks: [] },
          { id: "doing", title: "In Progress", tasks: [] },
          { id: "review", title: "Review", tasks: [] },
          { id: "done", title: "Done", tasks: [] },
        ],
      })
      router.push(`/board/${docRef.id}`)
    } catch (error) {
      console.error("Error creating new board:", error)
      setLoading(false)
    }
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-indigo-50 to-purple-50 dark:from-gray-900 dark:to-gray-800">
      <div className="container mx-auto px-4 py-8">
        <button
          onClick={() => router.back()}
          className="flex items-center text-gray-600 dark:text-gray-300 hover:text-gray-900 dark:hover:text-white mb-8"
        >
          <ArrowLeft className="w-5 h-5 mr-2" />
          Back
        </button>

        <div className="max-w-md mx-auto">
          <div className="bg-white dark:bg-gray-800 rounded-xl shadow-lg p-8">
            <div className="flex items-center justify-center mb-8">
              <Layout className="w-12 h-12 text-indigo-500" />
            </div>

            <h1 className="text-2xl font-bold text-center mb-8 text-gray-900 dark:text-white">Create New Board</h1>

            <form onSubmit={handleSubmit} className="space-y-6">
              <div>
                <label htmlFor="boardName" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                  Board Name
                </label>
                <input
                  type="text"
                  id="boardName"
                  value={boardName}
                  onChange={(e) => setBoardName(e.target.value)}
                  className="w-full px-4 py-2 rounded-lg border border-gray-300 dark:border-gray-600 focus:ring-2 focus:ring-indigo-500 dark:focus:ring-indigo-400 focus:border-transparent bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
                  placeholder="Enter board name"
                  required
                />
              </div>

              <button
                type="submit"
                disabled={loading}
                className="w-full bg-indigo-500 text-white py-2 px-4 rounded-lg hover:bg-indigo-600 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:ring-offset-2 disabled:opacity-50 disabled:cursor-not-allowed transition-colors duration-200"
              >
                {loading ? "Creating..." : "Create Board"}
              </button>
            </form>
          </div>
        </div>
      </div>
    </div>
  )
}

