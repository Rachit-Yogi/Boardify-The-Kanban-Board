"use client";

import { useState, useEffect } from "react";
import { auth, db } from "../../lib/firebase";
import { collection, query, where, getDocs } from "firebase/firestore";
import Link from "next/link";
import { useRouter } from "next/navigation";

export default function BoardsPage() {
  interface Board {
    id: string;
    name: string;
    createdAt: string;
  }

  const [boards, setBoards] = useState<Board[]>([]);
  const router = useRouter();

  useEffect(() => {
    const user = auth.currentUser;
    if (!user) {
      router.push("/signin");
      return;
    }

    const fetchBoards = async () => {
      const boardsRef = collection(db, "boards");
      const q = query(boardsRef, where("userId", "==", user.uid));
      const querySnapshot = await getDocs(q);
      const boardsData = querySnapshot.docs.map((doc) => ({
        id: doc.id,
        name: doc.data().name || "Untitled Board",
        createdAt: doc.data().createdAt || new Date().toISOString(),
      }));
      setBoards(boardsData);
    };

    fetchBoards();
  }, [router]);

  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-3xl font-bold mb-6">Your Boards</h1>
      
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {boards.map((board) => (
          <Link href={`/board/${board.id}`} key={board.id}>
            <div className="card hover:shadow-lg transition-shadow duration-200 cursor-pointer">
              <h2 className="text-xl font-semibold mb-2">{board.name}</h2>
              <p className="text-sm text-muted-foreground">Created: {new Date(board.createdAt).toLocaleDateString()}</p>
            </div>
          </Link>
        ))}
      </div>
      <button onClick={() => router.push("/board/new")} className="btn btn-primary mt-8">
        Create New Board
      </button>
    </div>
  );
}
