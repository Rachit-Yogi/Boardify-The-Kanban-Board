import AuthWrapper from "../components/AuthWrapper"
import BoardSelection from "../components/BoardSelection"

export default function Home() {
  return (
    <AuthWrapper>
      <BoardSelection />
    </AuthWrapper>
  )
}

